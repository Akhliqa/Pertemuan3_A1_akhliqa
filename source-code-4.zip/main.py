'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
str1 = "Py'thon"
print(str1)
str2 = 'Py"thon'
print(str2)
"\"OK, \" sampai ketemu lagi."
teks = "Python adalah bahasa pemrograman yang powerfull.\nTerbuktiPython bisa dijalankan di segala platform OS.\nJadi, saatnya kita menggunakanPython sebagai bahasa permrograman \nsehari-hari. Salam Python Dahsyat!"
print(teks)
kata = """Python adalah bahasa pemrograman yang powerfull.
... Terbukti Python bisa dijalankan di segala platform OS.
... Jadi, saatnya kita menggunakan Python sebagai bahasa pemrograman
... sehari-hari. Salam Python Dahsyat!"""
print(kata)