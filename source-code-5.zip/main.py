'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
blog = 'Klinik' + 'Python'
print(blog)
newblog = blog*5
print(newblog)
blog *= 4
print(blog)
string = 'Klinik' 'Python'
print(string)
buah = 'Nanas'
print(buah[0])
print(buah[0:2])
print(buah[0:4])
print(buah[0:5])